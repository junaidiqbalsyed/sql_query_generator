import gc
import os
import glob
import  json
import openai
import  shutil
from fastapi import FastAPI, Query
from databse.base import SQLDatabase
from langchain.chat_models import ChatOpenAI
from root.sql_query_generator import Sql_Query_Generator
from fastapi import FastAPI, Cookie, Response, UploadFile
from databse.sql_connection import my_sql, pg_sql, ms_sql
from databse.bigquery_schema_generator import generate_schema

app = FastAPI()


# This class is used to store the states specific to the user
class User_inputs:
    def __init__(self):

        self.database_type = None
        self.connection=False
        self.api= False
        self.database_name=None
        self.db=None
        self.schema=None
        


# sql = User_inputs()
user_objects = {'Kamal':[],'Venky':[],'Vinay':[],'Yash':[],'Nikhil':[], 'J.D':[]}
user_call = {'Kamal':{},'Venky':{},'Vinay':{},'Yash':{},'Nikhil':{}, 'J.D':{}}
# user_name=str()

@app.post("/user/{user_name}/object")
def get_user_object(user_name: str,
                    response: Response):
    """
    This function is used to get the registered authorised user
    """
    global user_objects
    global user_call

    # if user does not exsist then throw error
    if user_name not in user_objects:
        return {"message": "User not found"}

    # if user exist, create object for the user
    else:
        response.set_cookie(key="user_name", value=user_name)
        object_name = user_name + '_' + str(len(user_objects[user_name]))
        user_objects[user_name].append(object_name)
        user_objects[user_name][-1] = User_inputs()
        user_call[user_name][user_objects[user_name][-1]]=[] 
        print(user_objects)
    
    return 'Object created'


@app.post("/database_type")
async def database_type(user_name: str,
                        db_type: str = Query('select db',
                                             enum=['MySQL', 'BigQuery', 'Postgres', 'MsSQL'],),
                        upload_or_connect : str = Query('Upload_Schema',
                                             enum=['Upload_Schema', 'Connect_To_DB'], )
                        ):
        """
        This function allows the user to select the DB type user wants to work with
        """

        user_objects[user_name][-1].database_type = db_type
        user_objects[user_name][-1].upload_or_connect= upload_or_connect

        return "Database type stored"

@app.post("/upload_schema")
async def upload_schema( user_name: str,
                         schema : UploadFile,
                         database_name : str):
    if user_objects[user_name][-1].upload_or_connect == 'Upload_Schema':
        # save the uploaded json file to 'google_config_file' folder
        dest = os.path.join('./schemas/', schema.filename)

        with open(dest, "wb") as buffer:
            shutil.copyfileobj(schema.file, buffer)

        file_path = glob.glob("./schemas/*.json")[0]

        # load the json schema
        try:
            with open(file_path, 'r') as json_file:
                user_objects[user_name][-1].schema = json.load(json_file)

        except FileNotFoundError:
            print(f"The file '{file_path}' does not exist.")
        except json.JSONDecodeError:
            print(f"The file '{file_path}' is not valid JSON.")

        # load schema from json file to the object
        user_objects[user_name][-1].database_name = database_name
        user_objects[user_name][-1].connection = True

        return 'schema uploaded'
    else:
        return "you have opted to connect to your database "



@app.post("/connect_to_BigQuery")
async def connect_to_BigQuery(user_name: str,
                              config_file: UploadFile,
                              project_id: str,
                              database_id: str):
    """
    with this function we establish connection with google bigquery
    """
    if user_objects[user_name][-1].database_type == 'BigQuery' and user_objects[user_name][-1].upload_or_connect == "Connect_To_DB" :

        # if there is a pre-existing config file delete it

        # Directory path
        directory = './google_config_file/'

        # List all files in the directory
        files = os.listdir(directory)

        # Iterate through the files and delete those ending with '.json'
        for file in files:
            if file.endswith('.json'):
                file_path = os.path.join(directory, file)
                os.remove(file_path)

        # save the uploaded json file to 'google_config_file' folder
        dest = os.path.join('./google_config_file/', config_file.filename)

        with open(dest, "wb") as buffer:
            shutil.copyfileobj(config_file.file, buffer)

        # assign config file to environment
        os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = glob.glob("./google_config_file/*.json")[0]

        # if there is a pre-existing big-query schema, delete it



        # Iterate through the files and delete those ending with '.json'
        if len(glob.glob("./schemas/*.json")) > 0:
            for file in glob.glob("./schemas/*.json"):
                os.remove(file)

        # generate schema
        try:
            generate_schema(project_id= project_id , database_id= database_id)
        except:
            return 'failed to generate schema, check your bigquery credentials folder or data base details'

        #
        # Specify the path to the JSON file
        file_path = glob.glob("./schemas/*.json")[0]

        # load the json schema
        try:
            with open(file_path, 'r') as json_file:
                user_objects[user_name][-1].schema = json.load(json_file)

        except FileNotFoundError:
            print(f"The file '{file_path}' does not exist.")
        except json.JSONDecodeError:
            print(f"The file '{file_path}' is not valid JSON.")

        # load schema from json file to the object
        user_objects[user_name][-1].database_name = database_id
        user_objects[user_name][-1].connection = True
        return 'connected to BigQuery and loaded schema'
    else:
        return 'select correct database'


@app.post("/connect_to_DB")
async def connect_to_DB(user_name: str,
                          user_name_DB:str,
                          password:str,
                          host:str,
                          port:str,
                          database_name:str):
    """
    This function connects to database
    """
    
    if user_objects[user_name][-1].database_type in ['MySQL', 'Postgres', 'MsSQL'] and user_objects[user_name][-1].upload_or_connect == "Connect_To_DB" :
        # connect to MsSQL
        if user_objects[user_name][-1].database_type == 'MySQL':
            user_objects[user_name][-1].engine = my_sql(user_name_DB, password, host, port, database_name)
        # connect to postgres
        elif user_objects[user_name][-1].database_type == "Postgres":
            user_objects[user_name][-1].engine = pg_sql(user_name_DB, password, host, port, database_name)
        # connect to MsSQL
        elif user_objects[user_name][-1].database_type == "MsSQL":
            user_objects[user_name][-1].engine = ms_sql(user_name_DB, password, host, port, database_name)

        # establish connection
        try:
            user_objects[user_name][-1].db = SQLDatabase(engine = user_objects[user_name][-1].engine)
            user_objects[user_name][-1].schema = user_objects[user_name][-1].db.get_table_info()
        except:
            return f"please check your MsSQL credentials"

        user_objects[user_name][-1].connection = True
        user_objects[user_name][-1].database_name = database_name
        return f"connection to {user_objects[user_name][-1].database_type} established"
    else:
        return "please provide connection to correct database"


@app.post("/openai_api_key")
def openai_api_key(user_name: str,
                   api_Key: str):
    """
    collect api key
    """
    os.environ["OPENAI_API_KEY"] = api_Key
    openai.api_key = os.getenv("OPENAI_API_KEY")
    try:
        openai.Model.list()
    except:
        return "Incorrect API key provided"

    user_objects[user_name][-1].api = True
    return "api accepted"


@app.post("/generate_sql_query")
def generate_sql_query(user_name: str,
                       task: str):
    """
    given the task, DB type, schema generate sql query
    """

    if user_objects[user_name][-1].api and user_objects[user_name][-1].connection:

        gen = Sql_Query_Generator(llm= ChatOpenAI(model='gpt-4'))
        gen.execute_task(task= task,
                         schema = user_objects[user_name][-1].schema,
                         db_type = user_objects[user_name][-1].database_type,
                         db_name = user_objects[user_name][-1].database_name
                         )

        file_name = './generated_sql_quey/'+task.replace(' ', '_')+'.txt'
        text = ""
        try:
            with open(file_name, 'r') as file:
                # Read and print each line in the file
                for line in file:
                    text = text + line
                    #print(line, end='')  # 'end='' is used to avoid extra newline characters

        except FileNotFoundError:
            print(f"The file '{file_name}' was not found.")

        return text

    else:
        return "check your db connection or the open AI API key"


@app.post("/clear_history")
def clear_history(user_name: str):
    """
    deletes  previously generated queries, stored schemas and configurations
    """

    if len(glob.glob("./generated_sql_quey/*txt")) > 0:

        for file in glob.glob("./generated_sql_quey/*.txt"):
            os.remove(file)

    if len(glob.glob("./schemas/*.json")) > 0:

        for file in glob.glob("./schemas/*.json"):
            os.remove(file)

    if len(glob.glob("./google_config_file/*.json")) > 0:

        for file in glob.glob("./google_config_file/*.json"):
            os.remove(file)

    gc.collect()

    return "cleared history"

        

